// search index for WYSIWYG Web Builder
var database_length = 0;

function SearchPage(url, title, keywords, description)
{
   this.url = url;
   this.title = title;
   this.keywords = keywords;
   this.description = description;
   return this;
}

function SearchDatabase()
{
   database_length = 0;
   this[database_length++] = new SearchPage("index.html", "SPRCPU", "sprcpu super central proccessing unit سایت دوباره طراحی شد توسط آریشرر نجفی تمام اسکریپت ها تیم نوشته شده است بیشتر بات پیامرسان ساز کامل پیام رسان که قبلا از محصولات پرطفدار سوپر سنترال پراکسینگ یونیت بود سایلنت این بار با کیبورد اینلاین f80 در حال آپگرید قابلیت های جدید میباشد به همراه عضو دارد روی ورژنی کار میکند copyritghts sprinfocpu gmail cominstagram com ", "");
   this[database_length++] = new SearchPage("shop.html", "Untitled Page", "untitled page super central proccessing unit sprcpu copyritghts sprinfocpu gmail cominstagram com double click tارتباط با ما to ediمحصولات در یک نگاه ", "");
   this[database_length++] = new SearchPage("page1.html", "Untitled Page", "untitled page ", "");
   this[database_length++] = new SearchPage("page3.html", "Untitled Page", "untitled page ", "");
   this[database_length++] = new SearchPage("page4.html", "Untitled Page", "untitled page ", "");
   this[database_length++] = new SearchPage("page5.html", "Untitled Page", "untitled page ", "");
   this[database_length++] = new SearchPage("page6.html", "Untitled Page", "untitled page ", "");
   this[database_length++] = new SearchPage("login_signup.html", "Untitled Page", "untitled page ورود نام کاربری پسورد بخاطر سپردن اطلاعات ثبت فوری اسم تاییدیه mail یا کنید ", "");
   this[database_length++] = new SearchPage("client.html", "aboutus", "aboutus ", "");
   this[database_length++] = new SearchPage("index.html", "Untitled Page", "untitled page messages editmembers can edit messages? pinadmins pin something? replymembers reply floodmembers send flood messges? spammembers many spam forwardmembers forward message? linkmmbers link? usernamemembers usernames start with hashtagmembers tags silent groupmembers photomembers image? contactmembers share contact? musicmembers musics? audiomembers audio? locationmembers location? videomembers video? gifsmembers gif files? stickermembers sticker? documentsmembers docs file? language group languagewhats the language? filtermembers have filtering? bots bot protectionbots allow in group? gamemembers play game? inline optionsmembers or use options? close setting house desktop login name option chartershow charts max time ", "");
   this[database_length++] = new SearchPage("login_signup.html", "Untitled Page", "untitled page ", "");
   return this;
}
